===The resource pack HAS been updated with this update!===  
===Current RP Version: "for 0.1.6"===  
===Minecraft Compatibility: 1.20.1===  

## Sunrise 0.0.1.6 "Dawn" Changelog:  

### Quality of Life:  
    -Purchasing Empowerments now presents the player with similar in-world popups as Imbuement, rather than spamming their chat.  
    -Right clicking ("interacting") on an in-world popup now removes it. Left clicking ("attacking") now must be used to confirm a selection.  
        -Getting rid of a popup manually has a "swipe" sound effect to help communicate this as intended behavior.  
    -Added proper base stat descriptions to the heirloom items.  
    -Adjusted the "volume" parameter of lots of imbuement and empowerment related sounds - you shouldn't be able to hear your friends frantically applying imbuements from over a hundred blocks away anymore.

### New Config Setting:  
    -Dimensional Minimum Difficulty (dimensionmindifficulty.mcfunction)  
        -Enabling this setting causes players' Personal Difficulties to be set to Burning in the Nether, or Hellfire in the End, if they were on a lower difficulty going in. Players cannot set their difficulty below these levels while in those dimensions.

### Balance:  
    -Nerfed skeleton arrow damage on Spicy, Hot, and Burning p-diffs to make them less likely to surprise-kill early game players:  
        -Spicy: Skeleton arrow damage buff now +17.5% (was +25%)  
        -Hot: Skeleton arrow damage buff now +45% (was +75%)  
        -Burning: Skeleton arrow damage buff now +100% (was +125%)  
    -Nerfed Upwind (Sneak, Aerial)  
        -Cooldown now ~84 ticks (up from ~60).  
            -Players can no longer use Aerial Sneak Upwind to indefinitely float across horizontal distances.  
    =Strength Imbuement:  
        +Tier 3 now has an imbuement mechanic on top of its base stat bonus, called "More Than Might":  
            +Having 3500 or more Protector EP investment gives a minor stunning effect to your melee strikes.  
            +Having 3500 or more Scavenger EP investment gives you the chance for lucky crits.  
        +Tier 4 now provides a minor variant of Cleave, at half its effectiveness.  
        -Tier 4 gives only half the benefits to your base melee stats.  
    +Truth Imbuement:  
        +Tiers 2 and 4 provide +20% chance to conserve arrows on-hit, for a maximum of +40%.  
        =This bonus is Additive with Hunt (changes listed below), providing up to 90% conservation chance (wowee!).  
    +Reinforcing gold tools now costs 25 levels (was 30).  
    +Singe (rework):  
        +Concentrated/"follow-up" beams now deal damage.  
        +Follow-up beams have random spread of up to 40 degrees in both horizontal and vertical directions.  
        +Initial beam is now blue to make it more clear that it doesn't have spread randomization.  
        +Initial beam ignores I-frames.  
        +Singe can now be re-fired 3 game ticks faster.  
        -Basic attack casting cost increased to 1000 Focus (was 750).  
    +Hunt:  
        +Received 50% chance to conserve arrows on-hit.  
            Note - Missed arrows can still be picked up normally. Conservation chance *only* applies on a successful hit.  
        -Base damage now 70% of a vanilla bow.  
        +Adjusted its minor augments to provide more arrow damage across the board, but not quite as much as an augmented vanilla bow.  
        Dev Commentary (Ravioli): Hunt, in its previous state, was exactly the same in a statistical sense as a normal vanilla bow, and ran into issues in the early game regarding ammo, since collecting/crafting arrows is often a challenge or a pain at that point in the game. Now, Hunt serves as an ammo efficient alternative that you'll probably upgrade from later once ammo is a non-issue, though its major augmentations are still there to make it a worthy sidegrade to a standard bow.  
    +Ceremony:  
        +Buffed its base armor to 4 (was 2), and the armor buff now also applies to the offhand.  
    +Melee lucky critical hits now multiply base damage by 1.33x (was 1.2x)  
    +Hidden Art: Melee  
        +Tier 2 forced critical hits now deal 1.5x damage (was 1.2x by mistake)

### Roguelite Mode (Does not effect non-RL mode):  
    -If a player drops their Imbuer, Empowerer, or Augmentation Table, it will be deleted.  
        -When running back to grab items after a death, it is common for the player to simply die again, sometimes over and over. This causes the area to become absolutely littered with these items and this was a huge annoyance for some players. Now that these items despawn very quickly, this won't be a problem.  
    -To carry beds, players must now carry them in their main or offhand or else they will be dropped.  
        -Carrying extra beds was an exploit that had the potential to trivialize the impact of losing items on death. Now, players can only effectively carry one bed, taking up a gear slot, to *maybe* get a respawn point close enough to recover their items.  
        -This also prevents bed-bombing your way to victory.  
    -Dimensional Minimum Difficulty is now enabled in singleplayer.  

### Bugfixes:  
    -(!!!) Harvest (Jump) no longer has the potential to damage all hostile mobs on the server.  
    -(!) Smithing diamond gear to netherite now properly upgrades the item's base stats.  
    -Trying to upgrade an imbuement past tier 6 will no longer cause a bugged menu popup.  
    -Trimmed armor may now be augmented.  
    -Upwind (Sneak, Aerial) now centers its trail particles on the player rather than at the world spawnpoint. 
    -Shields that had a major augment cleared can now be re-augmented. Only applies to newly augmented shields.  
    -Fixed some inconsistencies with reinforcement price listings.  
    -Fixed baby zombies being faster than intended.  
    -Fixed magic damage causing more knockback than intended.  
    -Fixed Singe's raycast hitboxes being off-center from the beam.  
    -Heirloom items no longer lose some custom data altogether when clearing augmentations.  
        -Notably, this was an issue with Ceremony losing its attack damage and speed when clearing augments.  

### Technical:  
    -"Common" item loot tables:  
        -augtable.json: Added "esitem:augtable" and "es.rl.itemclear:1b" to the Augmentation Table's item tags.  
        -Also added "es.rl.itemclear:1b" to the loot tables:  
            -empowerer.json  
            -imbuer.json  
    -Added support for two new custom attributes for bows and crossbows. Currently, these are only used on Hunt, but they may be used later for other unique bows or augments.  
        -es.arrow_conserve_chance: Items tagged with this can have their arrow conservation chance defined in essences:arrows/conserve_chance  
        -es.arrow_dmg_base_overrided: Items tagged with this can have their arrow's base damage overridden in essences:arrows/lookups/base_dmg_overrides  
  
### Misc:  
    -Corrected the description for Resilience's 'Collected' mechanic to state "Soul Hearts" instead of "Soul Health".  
    -Changed the lore texts for heirloom items to be less needlessly verbose.

------------------

## Sunrise 0.0.1.5b "Dawn" Changelog:  
  
### Hotfixes (over 0.0.1.5):  
    -Teleport requests should no longer loop if left unaccepted.
    -Empowerments should be purchasable at their prices listed on the actionbar popup.

## Sunrise 0.0.1.5 "Dawn" Changelog:  

### Quality of Life:  
    -The Imbuer has received a new highly useful UI popup! Having the Imbuer in either hand now displays your held EP, Imbuement allocation, and selected difficulty.  
        -This was maddening to make please enjoy it.  
    -The Empowerer has received a similar popup! Holding the book in your hand now displays your set of bindings on-screen, your empowerments' cooldowns, and even shows how much it will cost to learn another Empowerment!  
    -Clicking on an Imbuement selection now puts the info about the upgrade in front of you, physically, rather than spamming your chat!  
        -This system should be expanded on in the next update or two - I wanted to reduce chat spam in many areas of the pack, but felt I had to get 0.0.1.5 out the door before I could implement more in-world popups to replace chat buttons.  

### General:  
    -Empowerments now have dynamic EP costs to learn depending on how many you have already learned, making your favorites much easier to obtain in the early game.  
    -Charging Erupt (Sneak) for too long now causes all of your empowerments to be placed on cooldown. Jump slots are penalized for half the time of Sneak slots.  

### Presentation:  
    -Item card pack signatures have been replaced - now they use a small icon to represent the pack, and are colored gold.  
        -Note: This change breaks existing ERPG item card lores, which will now contain unresolved translation strings. Sorry!  

### Channelers:  
    -Removed.  
        Developer Commentary (Ravioli): Alright, I feel I should explain myself here. The original 7 channeler items, simply put, were not up to quality standard and no longer fit with the design goals of the pack. Although a few of them had special attention given to them at various points of development in an attempt to keep them up to snuff, they simply still weren't cutting it in my opinion. Originally, channelers, alongside empowerments, were supposed to be the sole reasons a player would upgrade the Focus Imbuement, but these items provided utility to players that was either far too powerful or absolutely pitiful, with only a select couple being properly balanceable. And otherwise, they just felt janky. Despite being the pack's oldest legacy feature (predating even imbuement!), I think it's time to acknowledge that they were just early experiments with datapacking and let them go. I want to bring back some of the ideas that channelers had in a future update, perhaps recycle their abilities to be used elsewhere.  

### Bugfixes:  
    -Clearing augments from a major augmented bow or crossbow no longer bans them from the augment table.  
    -Tier 1 Regen now considers only red HP when determining if the player should be healed - having absorption HP no longer makes the bonus more strict.  
    -Having multiple players on the server will no longer boost players' passive focus regeneration.  
    -The [Changelog] link in the Imbuer now links correctly to the Sunrise version of the pack.  
    -The Empowerment purchase confirmation screen now correctly state that Protector and Scavenger Empowerments require their respective EP types to learn.  
    -Spectral arrows are no longer invisible.  
    -A few Empowerments triggered cooldowns for the wrong binding slot - this is now corrected.  
    -Fixed some behavior regarding Erupt (Sneak) being overcharged.