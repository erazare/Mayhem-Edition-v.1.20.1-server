===The resource pack HAS been updated with this update!===  
===Current RP Version: v1.18===  
===Minecraft Compatibility: 1.20.1===  

Sunrise 0.0.1.5b "Dawn" Changelog:  
  
Hotfixes:  
    -Teleport requests should no longer loop if left unaccepted.
    -Empowerments should be purchasable at their prices listed on the actionbar popup.

Sunrise 0.0.1.5 "Dawn" Changelog:  

Quality of Life:  
    -The Imbuer has received a new highly useful UI popup! Having the Imbuer in either hand now displays your held EP, Imbuement allocation, and selected difficulty.  
        -This was maddening to make please enjoy it.  
    -The Empowerer has received a similar popup! Holding the book in your hand now displays your set of bindings on-screen, your empowerments' cooldowns, and even shows how much it will cost to learn another Empowerment!  
    -Clicking on an Imbuement selection now puts the info about the upgrade in front of you, physically, rather than spamming your chat!  
        -This system should be expanded on in the next update or two - I wanted to reduce chat spam in many areas of the pack, but felt I had to get 0.0.1.5 out the door before I could implement more in-world popups to replace chat buttons.  

General:  
    -Empowerments now have dynamic EP costs to learn depending on how many you have already learned, making your favorites much easier to obtain in the early game.  
    -Charging Erupt (Sneak) for too long now causes all of your empowerments to be placed on cooldown. Jump slots are penalized for half the time of Sneak slots.  

Presentation:  
    -Item card pack signatures have been replaced - now they use a small icon to represent the pack, and are colored gold.  
        -Note: This change breaks existing ERPG item card lores, which will now contain unresolved translation strings. Sorry!  

Channelers:  
    -Removed.  
        Developer Commentary (Ravioli): Alright, I feel I should explain myself here. The original 7 channeler items, simply put, were not up to quality standard and no longer fit with the design goals of the pack. Although a few of them had special attention given to them at various points of development in an attempt to keep them up to snuff, they simply still weren't cutting it in my opinion. Originally, channelers, alongside empowerments, were supposed to be the sole reasons a player would upgrade the Focus Imbuement, but these items provided utility to players that was either far too powerful or absolutely pitiful, with only a select couple being properly balanceable. And otherwise, they just felt janky. Despite being the pack's oldest legacy feature (predating even imbuement!), I think it's time to acknowledge that they were just early experiments with datapacking and let them go. I want to bring back some of the ideas that channelers had in a future update, perhaps recycle their abilities to be used elsewhere.  

Bugfixes:  
    -Clearing augments from a major augmented bow or crossbow no longer bans them from the augment table.  
    -Tier 1 Regen now considers only red HP when determining if the player should be healed - having absorption HP no longer makes the bonus more strict.  
    -Having multiple players on the server will no longer boost players' passive focus regeneration.  
    -The [Changelog] link in the Imbuer now links correctly to the Sunrise version of the pack.  
    -The Empowerment purchase confirmation screen now correctly state that Protector and Scavenger Empowerments require their respective EP types to learn.  
    -Spectral arrows are no longer invisible.  
    -A few Empowerments triggered cooldowns for the wrong binding slot - this is now corrected.  
    -Fixed some behavior regarding Erupt (Sneak) being overcharged.



---------------------------------
Sunrise 0.0.1.4 "Dawn" Changelog:

!!! IMPORTANT !!!
    -This build includes CRITICAL bugfixes regarding the personal difficulty system. If your game has felt too easy, this is why!

Balance:
    +Guard Break:
        +Changed the "Weakened" and "Faltered" thresholds in the player's favor.
            Explanation - "Guard Weakened" now happens sooner, which gives the player more time to prepare for Falter. When Falter occurs, the player is given a little bit more grace before a Guard Break occurs. Specifically, those who aren't trying to block damage with a shield during Falter are given an extra 1-2 hits before a break occurs on Molten, depending on their Armor Toughness.
    +Recoup (Sneak):
        +Now causes Resilience to instantly trigger upon use.

Quality of Life:
    +Focus attacks now tag the player as the attacker
        +Focus users no longer have to hit enemies with a melee strike or arrow to get them to drop ERPG-related drops!
        Note - thank you Mojang for /damage :D

Technical:
    -Added a small guide to the readme.md file which specifies how to add your own datapack's custom mobs to ERPG's difficulty and loot systems.

Bugfixes:
    -CRITICAL: Fixed an issue where difficulty scaling would not apply if a mob was basically any distance away from the server's spawnpoint.
    -CRITICAL: Fixed an issue where mob variants would not apply if a mob was basically any distance away from the server's spawnpoint.
    -Added the Warden to the "bosshostiles" tag - the Warden will now regenerate health on Molten.
    -In-game quick config now states that "Wrist-Slapping" is 25% EP loss on death, *not* 10%.



---------------------------------
Sunrise 0.0.1.3 "Dawn" Changelog:

Guard Break Rebalance (Experimental):
    =Various value changes across the board to Guard Break have been made. Some such changes might make certain sources of guard damage too lenient, and others too punishing. If you notice anything out of wack, please let me know!
    +Max health penalty reduced from -.33 multiplicative to -.2 multiplicative.
    -Upon guard break, lose any absorption hearts you may have had.
    +Mechanical clarity changes:
        =Guard now restores whenever Resilience (RES) Imbuement triggers, rather than at a constant rate.
        =If the player does not have at least Tier 1 RES, then Guard restores instead when Tier 1 RES would have triggered.
        +The player is given two warnings before their guard is broken. These warnings also denote points of "guard gate", where you cannot be guard damaged past these points in one tick of damage.
    -Shield nerf:
        -Damage blocked by shields now contributes to Guard Break. Unlike taking health damage, blocked damage contributes proportionally to Guard Break.
        -If the player is guard broken, shields only block 40% of incoming damage.
    Developer commentary: Quite frankly, I am sick and tired of noticing people only ever running Sword n' Board. Find more creative builds. If you really, really want to still run the board, you'll have to think before you block or you may end up eating dirt. I know this shield nerf is going to be controversial - which is why the Guard Break rebalance is considered experimental. It's still possible that I will change or revert this nerf, but please, learn to not abuse the shield.

Bugfixes:
    -Disabled the old mastery bonuses, for real this time.



---------------------------------

Sunrise 0.0.1.2 "Dawn" Changelog:

Mob Variants:
    -Creepers now have a third custom mob variant!
        -Reeker: These creepers stink so bad, they can't explode! But man, do they reek... Get too close, and instead of blowing up, they release a continuous cloud of toxic fumes which ignore armor and deal massive guard break damage!

Technical: 
    -Added support for attribute-based damage versus players. Reekers currently use this system - if something seems fishy about it (besides their smell), let me know! Better to fix things early.
        -This might already be obsolete because of the /damage command in 1.19.4. However, this attribute damage system accepts variable input without the need for a function tree - I may end up keeping this system for the future, as ERPG very much needs variable input for things like damage.
    -Changed the augment table's font to utilize a space provider instead of an older method to achieve negative space.
        -Basically, if this change works, you won't notice anything wrong.

Balance:
    =Adjusted Upwind (Sneak):
        -Implemented a pierce limit of 3 for the harmful enemy tossing.
        =Players are no longer effected by the harmful toss, and are instead given the same effect that the caster receives.
        =Split the empowerment into grounded and aerial variants:
            =When used on the ground, act normally (with the balance changes listed above)
            -When used in the air, provides the caster with weaker levitation, and nearby players with no levitation.
            +When used in the air, provides the caster and nearby players with a temporary (2.5 second) speed bonus. Hit the ground running!
        Developer Commentary: Though chaining together sneakwinds to fly was one of my favorite things about the empowerment, I hadn't considered that it could be used to traverse the End with absolutely no safety risk. I wasn't satisfied to just nerf this ability, so I also provide players who use it with the choice to use it for bursts of movement speed on top of the existing fall damage negation. Changes to Upwind's interactions with players have been made in anticipation of the upcoming (but still distant) arena content. Better to test changes now, so they can get adjusted before the arena's release!

Misc:
    -Added an MIT license file to the pack.
    -Wisps have their model back! Unfortunately it doesn't look as good in motion as it did previously, though it's better than nothing. Mojang, please give Vex back the ability to display their headgear item.
    -All existing relic items except for Malaeus Tidebender are now denoted as "Sunset Relics" on the item card.
        -Going forward, relic items will have a different design approach - details aren't quite set in stone yet, but expect relics to be less static going forward.
        -If you do some digging in the code, you'll be able to preview the new system! Nothing *entirely* functional yet, though.
    -Updated the page 1 info prompt in the Empowerer to specify that binding handedness refers to what item slot your book needs to go in.

Hotfixes:
    -Updated the resource pack's version of ObjMC - grasses, ores, etc. should no longer have gross black outlining from a distance.
        -Thanks HahHujanApi from the Discord server for reporting this one!
    -Base movement speed granted via the Speed imbuement should no longer reset on login. 
        -Thanks TinCat from the Discord server for reporting this one!